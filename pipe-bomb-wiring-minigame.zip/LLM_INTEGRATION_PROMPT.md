# LLM INTEGRATION PROMPT — Pipe Bomb Wiring Minigame

**Paste this whole file to the coding agent, and give it access to this folder
plus the Godot project.** It is written to be read cold, with no other context.

---

## 0. What you are being asked to do

Reinstall a finished, tested Godot 4 minigame into the game project
`stick-figure-game-4`. It was built, playtested, approved, and then deliberately
removed to keep the main branch clean. Nothing here needs redesigning. Your job
is integration, not invention.

**Do not rewrite the minigame. Do not restyle the art. Do not retune the
difficulty numbers unless the human explicitly asks.** All three were reviewed
and signed off already.

---

## 1. The game this plugs into

`stick-figure-game-4` is a Godot 4.7 pass-and-play, two-player, top-down pixel
game about booby-trapping a roommate's bedroom.

- **Player 1** walks the room during a setup phase and plants traps on props.
  Three traps per round.
- **Player 2** then walks the same room and uses props. Using a trapped prop
  fires the trap; inspecting it first defuses it.
- One of the traps is a **pipe bomb on the dresser**. P1 stands at the dresser
  and presses **E** to plant it. When P2 later presses **E** on that dresser,
  the bomb ejects from the drawer, arcs through the air, and explodes.

Key facts you will need:

| Thing | Value |
|---|---|
| Engine | Godot **4.7.1** |
| Project root | `stick-figure-game-4/` (all scripts sit flat at the root, `res://`) |
| Main scene | `res://Stick Figure 4.tscn` — root node is `Main` |
| Turn state | `/root/Main/TurnManager`, script `turn_manager.gd` |
| Dresser trap | `dresser_area.gd`, an `Area2D` child of the `DresserProp` sprite |
| HUD | `turn_manager.gd` builds a `CanvasLayer` named `GameHUD` at layer 100, `process_mode = ALWAYS` |
| Pixel font | `res://PressStart2P-Regular.ttf` |
| Debug keys | `debug_cheats.gd`, F1–F12 |
| The human never opens the Godot editor | He playtests via a desktop `.bat`. You edit files on disk; he relaunches. |

There is a `HANDOFF.md` at the project root with fuller background. Read it.

---

## 2. What the minigame is

**"PIPE BOMB — DETONATOR WIRING."** A modal popup that opens when P1 presses E
on the dresser, *before* the trap is planted.

A clamp head sweeps up and down a rail of coloured terminal posts. The clamp
holds one coloured wire at a time. The player presses **SPACE / E** to clamp,
and must do it while the clamp is lined up with the post whose collar matches
the wire being held. Land every wire before the fuse timer runs out.

- **Skill** is the timing window — how precisely you stop the sweep.
- **Luck** is three things: post order reshuffles every attempt, a good clamp can
  still roll `LOOSE CONTACT` and force a redo, and MEDIUM/HARD throw random
  power surges that double the sweep speed and sometimes reverse it.

Difficulty picker (EASY / MEDIUM / HARD) appears at the top of every attempt.

**Outcome is pass/fail. There is no partial success.**

| Outcome | Meaning |
|---|---|
| `success` | Trap planted. Detonates normally when P2 uses the dresser. |
| `failed` | Fuse ran out or strikes maxed. Trap charge **is spent**, no trap planted. |
| `cancel` | Player hit ESC at the picker. Nothing spent, prompt returns. |

See `screenshots/` for exactly what it should look like when you are done.

---

## 3. Files in this package

```
godot/pipe_bomb_minigame.gd          the entire minigame, one self-building Control
godot/pipe_bomb_minigame/            art folder (7 sprite sheets)
    pb_*.png                         game-ready, magenta already keyed to alpha
    _src_magenta/                    un-keyed source plates + gen_art.py + notes
                                     (has a .gdignore — Godot skips it entirely)

integration/*.BEFORE.gd              the three touched files as they were
integration/*.AFTER.gd               the same three with the minigame wired in
integration/*.patch                  unified diffs, BEFORE -> AFTER

testing/                             headless verification harness (see §6)
screenshots/                         what a correct integration looks like
```

`pipe_bomb_minigame.gd` builds its whole UI in code. **There is no `.tscn` to
import and none is needed.** Do not create one.

---

## 4. Integration steps

### Step 1 — copy the assets

Copy into the project root, preserving structure:

```
pipe_bomb_minigame.gd        ->  <project>/pipe_bomb_minigame.gd
pipe_bomb_minigame/          ->  <project>/pipe_bomb_minigame/
```

Do not generate `.import` files by hand. Godot writes them on next launch. The
script has a raw-image fallback (`_load_tex`) so it survives the very first run
before the import completes.

### Step 2 — apply the three patches

Preferred: apply `integration/*.patch`. If the target files have drifted since
this package was made, do not force the patch — open the matching `.AFTER.gd`
and port the changes by hand. They are small and clearly commented. Here is
every change, so you can do it manually if you need to:

**`turn_manager.gd`** — four additions, no deletions:

1. Preload next to the existing `SpinWheelPopup` preload:
   ```gdscript
   const PipeBombMinigame = preload("res://pipe_bomb_minigame.gd")
   ```
2. Two vars next to `var _spin_wheel`:
   ```gdscript
   var _pipe_bomb_minigame: Control = null
   var pipe_bomb_difficulty: int = -1   # -1 ask, 0 easy, 1 medium, 2 hard
   ```
3. `_ensure_pipe_bomb_minigame()` and `show_pipe_bomb_minigame()`, placed right
   after the existing `show_spin_wheel()`. They mirror `_ensure_spin_wheel()`
   exactly — build once, parent to `_hud_layer`.
4. Two cheat methods, `cheat_pipe_bomb_minigame()` and
   `cheat_cycle_pipe_bomb_difficulty()`.

**`debug_cheats.gd`** — two lines in `_register_cheats()`, binding F2 and F3.

**`dresser_area.gd`** — the real integration. Two things:

- A `_minigame_running` guard at the very top of `_input()`, so the popup's
  keypresses cannot re-enter the dresser handler.
- P1's E branch no longer plants directly. It now checks `traps_left` and calls
  a new `await _set_pipe_bomb_trap()`, which runs the minigame and acts on the
  result.

**P2's side of `dresser_area.gd` is untouched. The eject / gib / explosion /
cartwheel code is byte-for-byte identical to before.** If your diff shows any
change inside `_eject_pipe_bomb`, `_gib_roomate` or `_play_explosion_at`, you
have made a mistake — revert it. That code is load-bearing and the human has
already been burned once by a change there.

### Step 3 — ordering rules that must not be broken

`_set_pipe_bomb_trap()` looks fussy. It is, for two real reasons. Preserve both:

1. **Mark the prop trapped BEFORE calling `consume_trap()`.**
   `consume_trap()` flips the turn when it hits zero traps, and
   `UsableShimmer.mark_trapped_p1()` paints the prop red. Call them in the wrong
   order and the red "this one is trapped" tint is on screen during P2's turn,
   which shows P2 exactly where the trap is. The original code had this bug; the
   fix is baked into the AFTER version. Keep it.

2. **Show and hide the result label BEFORE calling `consume_trap()`.**
   Same reason — "Trap Set!" must not still be on screen when the turn passes to
   P2. The 1.7 s read-then-hide happens first, `consume_trap()` last.

Also: lock P1's movement (`player1_body.set_movement_locked(true)`) for the
duration of the popup and unlock after.

---

## 5. The public API

```gdscript
# On TurnManager:
var result: Dictionary = await turn_manager.show_pipe_bomb_minigame()
```

```gdscript
{
  "outcome": "success",     # "success" | "failed" | "cancel"
  "difficulty": 2,          # 0 easy, 1 medium, 2 hard
  "difficulty_name": "HARD",
  "clean": true,            # zero strikes and <= 1 loose contact
  "strikes": 0,
  "loose": 1,
  "time_left": 8.4,         # fuse seconds remaining
}
```

`difficulty`, `clean`, `strikes`, `loose` and `time_left` are **not used by
anything yet**. They are deliberately returned so per-difficulty consequences
can be hung off them later — blast radius, stat swings, story beats, scoring.

**`dresser_area._set_pipe_bomb_trap()` is the single place that reads this
result.** If the human asks for difficulty to start mattering, that function is
where it goes. Do not scatter the logic.

`TurnManager.pipe_bomb_difficulty` forces a difficulty and skips the picker:
`-1` ask every time (default), `0` easy, `1` medium, `2` hard.

---

## 6. Verifying your work without a human

You can test this fully headless. This is how the minigame was originally
validated — do it again rather than declaring victory.

Get a Godot binary (4.3+ is fine for checking; the project targets 4.7):

```bash
# syntax check every touched script
godot --headless --path <project> --check-only --script pipe_bomb_minigame.gd
godot --headless --path <project> --check-only --script dresser_area.gd
godot --headless --path <project> --check-only --script turn_manager.gd
godot --headless --path <project> --check-only --script debug_cheats.gd
```

Then run the harness in `testing/` (copy the `.gd` files to the project root):

- **`smoke.gd`** — drives every code path: all three difficulties, ESC cancel,
  number-key difficulty select. Prints a tally. Expect `SMOKE OK` and no errors.

  ```bash
  godot --headless --fixed-fps 60 --path <project> --script smoke.gd
  ```

- **`bot.gd`** — plays the minigame with a bot at three aim precisions.
  **This is the important one.** Expected result:

  ```
  skill=0.45  { EASY/success: 15, MEDIUM/success: 15, HARD/success: 15 }
  skill=0.8   { EASY/success: 15, MEDIUM/success: 15, HARD/success: 15 }
  skill=1.6   { EASY/failed: 15, MEDIUM/failed: 15, HARD/failed: 15 }
  ```

  Precise aim must win on every difficulty; deliberately-off aim must lose on
  every difficulty. If skill=1.6 starts succeeding, the tolerance is too fat. If
  skill=0.45 starts failing, something is broken.

- **`screenshot.gd`** — renders real PNGs of the popup under Xvfb, so you can
  actually look at your integration instead of guessing:

  ```bash
  xvfb-run -s "-screen 0 1152x648x24" godot --path <project> \
      --resolution 1152x648 --rendering-driver opengl3 --script screenshot.gd
  ```

  Compare the output against `screenshots/`. The pixel font must be rendering —
  if the text looks like a plain sans-serif, `PressStart2P-Regular.ttf` is not
  importing and the popup will look wrong.

---

## 7. The art contract

If you touch the art at all, match this. It is the project's existing style,
lifted directly from `Room Cleaned 1.png`:

- 16-bit chunky pixels, **2 px minimum feature size**
- thick `#272736` outlines on every silhouette
- warm room palette, exact hexes below
- authored on **pure magenta `#FF00FF`**, keyed to alpha on export

```
#272736 outline   #322947 #473B78 #57294B shadows/plate
#73275C #8C3F5D #964253 #B0305C  wine / maroon
#BA6156 #E36956 #F2A65E #FFB570  rust / red / orange
#FFFFEB #FFE478                  cream / gold
#3CA370 #3D6E70                  green / teal
#4B5BAB #4DA6FF #66FFE3          blues / cyan
#7E7E8F #C2C2D1                  greys
```

`godot/pipe_bomb_minigame/_src_magenta/gen_art.py` regenerates every sprite from
scratch — edit the palette table or the `build_*` functions and re-run:

```bash
python gen_art.py     # writes out/magenta/ and out/keyed/
```

Then copy `out/keyed/*.png` over `pipe_bomb_minigame/pb_*.png`.

**Sheet layouts are load-bearing.** The script indexes frames by fixed cell size:

```
pb_board.png      176 x 152   single frame, board backdrop
pb_terminals.png   24 x  24   12 frames: colour*2 + (0 dim, 1 live)
pb_clamp.png       52 x  30    6 frames, one per wire colour
pb_wirestub.png    26 x  14    6 frames, one per wire colour
pb_spark.png       30 x  30    5 frames
pb_flame.png       16 x  18    4 frames
pb_bomb_icon.png   34 x  24   single frame
```

Wire colour order is **RED, BLUE, YELLOW, GREEN, WHITE, PINK** (index 0–5) and
must stay identical between `WIRE_COLORS` / `WIRE_NAMES` in the GDScript and the
`WIRES` table in `gen_art.py`. Board geometry the script depends on:
`RAIL_CX = 119`, `RAIL_TOP = 16`, `RAIL_BOT = 136`, clamp contact point inside
its own sprite `= (48, 15)`.

---

## 8. Tuning reference

Everything lives in the `CONFIG` array at the top of `pipe_bomb_minigame.gd`.

| | EASY | MEDIUM | HARD |
|---|---|---|---|
| wires / posts | 3 / 4 | 4 / 5 | 5 / 6 |
| sweep speed (board px/s) | 60 | 100 | 130 |
| clamp tolerance (board px) | 12 | 8 | 6 |
| resulting timing window | ~400 ms | ~160 ms | ~92 ms |
| fuse, ±12% jitter | 34 s | 28 s | 22 s |
| strikes allowed | 3 | 2 | 2 |
| loose-contact chance | 5% | 13% | 22% |
| surge chance / sec | — | 10% | 22% |

Timing window = `2 * tol / speed`. That is the number that actually decides how
hard it feels — change `speed` and `tol` together with it in mind. Below ~80 ms
stops being fair on a keyboard.

Penalties: a strike costs 3 s of fuse, a loose contact costs 1.5 s.

---

## 9. Reusing this for a different trap

The minigame knows nothing about dressers or pipe bombs beyond its own text.
To hang it on another prop:

1. Call `await turn_manager.show_pipe_bomb_minigame()` from that prop's Area2D
   script and branch on `outcome`.
2. Copy the `_minigame_running` guard and the movement lock/unlock.
3. Obey the two ordering rules in §4 step 3.
4. Retheme by editing the strings and re-running `gen_art.py` with different
   art. The mechanic — sweep, match, clamp — is prop-agnostic.

If you want several props to use it with different framing, generalise
`show_pipe_bomb_minigame()` into `show_wiring_minigame(title, art_dir)` rather
than copy-pasting the script.

---

## 10. Checklist before you tell the human it is done

- [ ] All four scripts pass `--check-only` with no errors
- [ ] `smoke.gd` prints `SMOKE OK`, no script errors
- [ ] `bot.gd` matches the expected win/loss table in §6
- [ ] `screenshot.gd` output visually matches `screenshots/`, pixel font rendering
- [ ] `diff` of `dresser_area.gd` shows **no change** inside `_eject_pipe_bomb`,
      `_gib_roomate`, or `_play_explosion_at`
- [ ] Prop is marked trapped, and the label shown+hidden, **before**
      `consume_trap()` is called
- [ ] P1 movement locks during the popup and unlocks after
- [ ] ESC at the picker spends nothing and restores the "Press E to Booby Trap" prompt
- [ ] You told him to test with the desktop `.bat`, and warned him the first
      launch is slower while Godot imports the new sprites
