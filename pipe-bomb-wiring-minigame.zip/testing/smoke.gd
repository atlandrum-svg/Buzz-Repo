extends SceneTree
const MG = preload("res://pipe_bomb_minigame.gd")

var _out := []
var _done := false

func _initialize() -> void:
	_run()

func _run() -> void:
	var layer := CanvasLayer.new()
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	root.add_child(layer)
	var mg: Control = MG.new()
	layer.add_child(mg)
	await process_frame

	var tally := {}
	for trial in 24:
		var diff: int = trial % 3
		var period: int = 5 + (trial % 11)   # vary the mash rate -> vary skill
		_done = false
		_out.clear()
		_play(mg, diff)
		var guard := 0
		while not _done and guard < 8000:
			guard += 1
			if guard % period == 0:
				var ev := InputEventKey.new()
				ev.keycode = KEY_SPACE
				ev.pressed = true
				mg._input(ev)
			await process_frame
		var r: Dictionary = _out[0] if _out.size() > 0 else {}
		var k := "%s/%s" % [String(r.get("difficulty_name","?")), String(r.get("outcome","?"))]
		tally[k] = int(tally.get(k, 0)) + 1
		if trial < 6:
			print("trial ", trial, " -> ", r)
	print("TALLY: ", tally)

	# cancel path
	_done = false
	_out.clear()
	_play(mg, -1)
	for i in 20: await process_frame
	var esc := InputEventKey.new(); esc.keycode = KEY_ESCAPE; esc.pressed = true
	mg._input(esc)
	var g2 := 0
	while not _done and g2 < 600:
		g2 += 1
		await process_frame
	print("CANCEL -> ", _out[0] if _out.size() > 0 else {})

	# picker navigate + start on HARD via number key
	_done = false
	_out.clear()
	_play(mg, -1)
	for i in 20: await process_frame
	var k3 := InputEventKey.new(); k3.keycode = KEY_3; k3.pressed = true
	mg._input(k3)
	var g3 := 0
	while not _done and g3 < 8000:
		g3 += 1
		if g3 % 9 == 0:
			var ev2 := InputEventKey.new(); ev2.keycode = KEY_E; ev2.pressed = true
			mg._input(ev2)
		await process_frame
	print("PICKER-HARD -> ", _out[0] if _out.size() > 0 else {})
	print("SMOKE OK")
	quit()

func _play(mg, diff) -> void:
	var r = await mg.show_and_play(diff)
	_out.append(r)
	_done = true
