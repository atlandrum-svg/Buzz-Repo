extends SceneTree
const MG = preload("res://pipe_bomb_minigame.gd")
var _out := []
var _done := false

func _initialize() -> void: _run()

## skill 1.0 = presses inside half the tolerance; lower = sloppier aim + lag
func _bot_should_press(mg, skill: float) -> bool:
	if mg._queue.is_empty(): return false
	var ci: int = int(mg._queue[0])
	for i in mg._term_y.size():
		if int(mg._term_colors[i]) != ci: continue
		if bool(mg._term_done[i]): continue
		var d: float = absf(float(mg._term_y[i]) - mg._clamp_y)
		# lead the target by one frame of travel (what a human does)
		var lead: float = mg._speed * (1.0/60.0) * mg._clamp_dir
		var d2: float = absf(float(mg._term_y[i]) - (mg._clamp_y + lead))
		return minf(d, d2) <= float(mg._cfg["tol"]) * skill
	return false

func _run() -> void:
	var layer := CanvasLayer.new(); layer.process_mode = Node.PROCESS_MODE_ALWAYS
	root.add_child(layer)
	var mg: Control = MG.new(); layer.add_child(mg)
	await process_frame

	for skill in [0.45, 0.8, 1.6]:
		var tally := {}
		for trial in 45:
			var diff: int = trial % 3
			_done = false; _out.clear()
			_play(mg, diff)
			var guard := 0
			var cooldown := 0
			while not _done and guard < 12000:
				guard += 1
				cooldown -= 1
				if mg._running and cooldown <= 0 and _bot_should_press(mg, skill):
					var ev := InputEventKey.new(); ev.keycode = KEY_SPACE; ev.pressed = true
					mg._input(ev)
					cooldown = 8
				await process_frame
			var r: Dictionary = _out[0] if _out.size() > 0 else {}
			var k := "%s/%s" % [String(r.get("difficulty_name","?")), String(r.get("outcome","?"))]
			tally[k] = int(tally.get(k,0)) + 1
		print("skill=", skill, "  ", tally)
	print("BOT OK"); quit()

func _play(mg, diff) -> void:
	var r = await mg.show_and_play(diff)
	_out.append(r); _done = true
