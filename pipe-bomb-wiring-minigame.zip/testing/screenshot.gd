extends SceneTree
const MG = preload("res://pipe_bomb_minigame.gd")
func _initialize() -> void: _run()
func _grab(n:String)->void:
	await process_frame; await process_frame
	root.get_texture().get_image().save_png("res://shots/%s.png" % n)
	print("shot ",n)
func _aim(mg, tight:float) -> bool:
	if mg._queue.is_empty(): return false
	var ci: int = int(mg._queue[0])
	for t in mg._term_y.size():
		if int(mg._term_colors[t]) == ci and not bool(mg._term_done[t]):
			return absf(float(mg._term_y[t]) - mg._clamp_y) <= float(mg._cfg["tol"])*tight
	return false
func _press(mg, code:int) -> void:
	var e := InputEventKey.new(); e.keycode = code; e.pressed = true; mg._input(e)
func _run() -> void:
	DirAccess.make_dir_absolute(ProjectSettings.globalize_path("res://shots"))
	var layer := CanvasLayer.new(); layer.process_mode = Node.PROCESS_MODE_ALWAYS
	root.add_child(layer)
	var mg: Control = MG.new(); layer.add_child(mg)
	await process_frame

	# 1 picker
	mg.show_and_play(-1)
	for i in 25: await process_frame
	await _grab("1_difficulty_picker")
	_press(mg, KEY_S); await process_frame
	_press(mg, KEY_SPACE)
	for i in 100: await process_frame
	await _grab("2_board_hard")
	# land two wires for a mid-game shot
	var landed := 0; var g := 0
	while landed < 2 and g < 4000:
		g += 1
		if mg._running and _aim(mg, 0.35):
			_press(mg, KEY_SPACE); landed += 1
			for i in 3: await process_frame
			if landed == 1: await _grab("3_contact_spark")
		await process_frame
	await _grab("4_progress")
	# finish it
	while mg._running and g < 12000:
		g += 1
		if _aim(mg, 0.35): _press(mg, KEY_SPACE)
		await process_frame
	for i in 40: await process_frame
	await _grab("5_success")
	for i in 120: await process_frame

	# failure shot
	mg.show_and_play(1)
	for i in 100: await process_frame
	var g2 := 0
	while mg._running and g2 < 8000:
		g2 += 1
		if g2 % 30 == 0: _press(mg, KEY_SPACE)
		await process_frame
	for i in 40: await process_frame
	await _grab("6_failure")
	print("DONE"); quit()
