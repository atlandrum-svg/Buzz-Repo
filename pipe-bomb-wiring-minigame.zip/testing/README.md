# Headless verification harness

Copy these .gd files to the Godot project root and run them with a Godot binary.
They need no display except screenshot.gd, which needs Xvfb.

    godot --headless --fixed-fps 60 --path <project> --script smoke.gd
    godot --headless --fixed-fps 60 --path <project> --script bot.gd
    xvfb-run -s "-screen 0 1152x648x24" godot --path <project> \
        --resolution 1152x648 --rendering-driver opengl3 --script screenshot.gd

smoke.gd       Drives every path: 3 difficulties x varied mash rates, ESC cancel,
               number-key difficulty select. Prints a tally, ends with SMOKE OK.
               Random mashing should FAIL every time — that is correct.

bot.gd         Plays with a bot at three aim precisions. This is the real test.
               Expected:
                 skill=0.45  EASY/MEDIUM/HARD success x15 each
                 skill=0.8   EASY/MEDIUM/HARD success x15 each
                 skill=1.6   EASY/MEDIUM/HARD failed  x15 each
               Precise aim must win everywhere, deliberately-off aim must lose
               everywhere. skill=1.6 succeeding means tolerance is too fat.

screenshot.gd  Renders PNGs into <project>/shots/ so you can look at the popup
               instead of guessing. Compare against ../screenshots/.
               If the text is a plain sans-serif rather than blocky pixels,
               PressStart2P-Regular.ttf is not importing.

Note: these drive the popup by calling mg._input(event) directly and by reading
mg._clamp_y / mg._term_y / mg._term_colors / mg._queue. That is deliberate white-
box testing. If you rename those members, update the harness.
