# Pipe Bomb Wiring Minigame — cold storage

Built for `stick-figure-game-4`, playtested, approved, then pulled back out of
the project to keep the main branch clean. Everything needed to put it back is
in this folder.

Packaged 2026-08-04.

---

## Reinstalling it

Hand an LLM **`LLM_INTEGRATION_PROMPT.md`** plus this folder and the game
project. That file is written to be read cold — it explains the game, the
minigame, every file to touch, the two ordering rules that matter, how to verify
headless, and what "done" looks like. You should not have to explain anything.

If you would rather do it yourself: copy `godot/` into the project root and
apply the three patches in `integration/`. That is the whole job.

---

## What it is

A modal popup that fires when Player 1 presses **E** on the dresser, before the
pipe bomb goes down.

A clamp head sweeps a rail of coloured terminal posts, holding one coloured wire
at a time. Press **SPACE / E** to clamp — you have to hit the post whose colour
matches the wire you are holding. Land them all before the fuse burns out.

Skill is the timing window. Luck is that the post order reshuffles every
attempt, a good clamp can still roll `LOOSE CONTACT` and make you redo that
wire, and medium/hard throw random power surges that double the sweep speed and
sometimes reverse it.

Pass/fail, nothing in between: **success** plants a trap that detonates
normally, **failed** burns the pipe bomb with no trap planted, **cancel** (ESC)
costs nothing.

Difficulty picker every attempt — EASY, MEDIUM, HARD. Difficulty currently only
changes how hard the minigame is; the result dictionary already carries
`difficulty`, `clean`, `strikes`, `loose` and `time_left` so consequences can be
hung off them whenever you want.

`screenshots/` shows all of it.

---

## What is in here

| Folder | Contents |
|---|---|
| `godot/` | The minigame script and its art. Drop straight into the project root. |
| `integration/` | The three touched project files, BEFORE and AFTER, plus unified diffs. |
| `testing/` | Headless harness — syntax check, path coverage, a skill bot, and a screenshot renderer. |
| `screenshots/` | What a correct integration looks like. |

The art is 16-bit chunky pixels with thick `#272736` outlines on the warm room
palette pulled from `Room Cleaned 1.png`, authored on pure magenta and keyed.
`godot/pipe_bomb_minigame/_src_magenta/` keeps the un-keyed source plates and
`gen_art.py`, which regenerates every sprite from scratch — that folder carries
a `.gdignore` so Godot never imports it.

---

## One thing worth knowing

The integration fixes a pre-existing bug in `dresser_area.gd`: the dresser used
to paint itself red *after* `consume_trap()` had already flipped the turn, which
meant Player 2 could see which prop was trapped. The AFTER version marks the
prop and clears the confirmation text before the turn passes. Keep that ordering
if you rework any of this — it is called out in §4 of the LLM prompt.

Player 2's side of the trap — the bomb ejecting, the roommate gib, the explosion
frames, the cartwheel — is byte-for-byte untouched, and should stay that way.
